#include <stdio.h>

int main()
{
   int i
   int j;

   for (i = 0; i <= 10; i++) {
       j = i * 7;
       printf("%d x 7 = %d\n", i, j);
   }
}
